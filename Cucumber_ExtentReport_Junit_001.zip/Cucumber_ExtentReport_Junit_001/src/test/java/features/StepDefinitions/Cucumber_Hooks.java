package features.StepDefinitions;

import java.io.IOException;

import org.apache.log4j.Logger;

import com.cucumber.listener.Reporter;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import eZLM.Automation.Accelerators.Browser;
import eZLM.Automation.Accelerators.Report;
import eZLM.Automation.Utilities.ConfiguratorFileSupport;
import features.TestRunner_StartingPoint;

public class Cucumber_Hooks {

	public static String Scenario_Name;
	public Logger Log = Logger.getLogger(Cucumber_Hooks.class);
	public static ConfiguratorFileSupport configProps = new ConfiguratorFileSupport(
			System.getProperty("user.dir") + "//" + "TLMConfiguration.properties");
	@Before
	public void BeforeScenario(Scenario scenario) {
		if (TestRunner_StartingPoint.Cleanup) {
			Report.cleanup();
			TestRunner_StartingPoint.Cleanup = false;
		}
		Report.Scenario_name = scenario.getName();

		Log.info(
				"------------------------------------Scenario Started---------------------------------------------------------------------------");
		Log.info("Scenario : " + scenario.getName() + " Started ");

	}

	@After
	public void AfterScenario(Scenario scenario) {

		Log.info("Scenario : " + scenario.getName() + " Ended ");
		Log.info(
				"---------------------------------------Scenario Ended------------------------------------------------------------------------");
		if(scenario.isFailed())
		{
			//String s="\\\\HYRDLT3080\\Users\\pandisan\\Downloads\\Share\\ScreenShots\\Adding_200_clock_in_Time_clock_configurationAND_Failed_to_Click_on_SearcH_button.jpeg";
			try {
				Reporter.addScreenCaptureFromPath(Report.ScreenShot_Path_Name);
				//Reporter.addScenarioLog("<a href="+s+">Screen Shot</a>");
				Browser.CloseAllSessions();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		Browser.SleepTime++;

	}

}
